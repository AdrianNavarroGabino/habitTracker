﻿/**
 * CargarTracker.cs - Habit Tracker, Opción "cargar tracker"
 * 
 * @author Adrián Navarro Gabino
 * 
 * Cambios:
 * 
 */

class CargarTracker
{
}