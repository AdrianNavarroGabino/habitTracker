﻿/**
 * NuevoTracker.cs - Habit Tracker, Opción "nuevo tracker"
 * 
 * @author Adrián Navarro Gabino
 * 
 * Cambios:
 * 
 */
class NuevoTracker
{
}