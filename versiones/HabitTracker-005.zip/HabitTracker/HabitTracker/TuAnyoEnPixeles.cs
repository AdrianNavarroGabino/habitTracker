﻿/**
 * TuAnyoEnPixeles.cs - Habit Tracker, Opción "tu año en píxeles"
 * 
 * @author Adrián Navarro Gabino
 * 
 * Cambios:
 * 
 */

class TuAnyoEnPixeles
{
}